for explanation go there
http://www.codingcage.com/2015/01/user-registration-and-login-script-using-php-mysql.html

To Do 
1. create a database in mysql call dbtest 
2.  open the dbconnect.php to check the database name , password etc.
    if you have a password dont forget to add in it 
3. open dbtest.sql
4. go to the dbtest in mysqladmin  then  click on sql
5. copy the content of dbtest.sql 
6. click on go 
7. open the code in xampp and try to register a user and log him in
